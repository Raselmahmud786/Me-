# AutoBoard Android App

ভিডিওর মতো floating signal-board UI-এর একটি native Android starter project।

## কী আছে
- Floating overlay board
- Drag করে screen-এর যেকোনো জায়গায় নেওয়া
- AI PRO status
- UP / DOWN / WAIT demo signal
- Close (×) button
- Start/Stop control
- Android overlay permission

## APK বানানো
Android Studio-তে project folder `AutoBoard` open করুন। তারপর:
`Build > Build APK(s)`

APK তৈরি হবে সাধারণত:
`app/build/outputs/apk/debug/app-debug.apk`

## গুরুত্বপূর্ণ
বর্তমান UP/DOWN হলো demo logic। এটি কোনো real market/broker data দেখে prediction করে না। Real signal চাইলে নির্দিষ্ট data source/API এবং আপনার signal rules যোগ করতে হবে।
