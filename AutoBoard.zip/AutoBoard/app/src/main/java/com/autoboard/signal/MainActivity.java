package com.autoboard.signal;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    @Override public void onCreate(Bundle b){ super.onCreate(b); build(); }
    void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(22),dp(26),dp(22),dp(22)); root.setBackgroundColor(Color.rgb(11,16,32));
        TextView title=new TextView(this); title.setText("AutoBoard"); title.setTextColor(Color.WHITE); title.setTextSize(30); title.setGravity(Gravity.CENTER); title.setTypeface(null,1);
        root.addView(title,new LinearLayout.LayoutParams(-1,dp(60)));
        TextView sub=new TextView(this); sub.setText("Floating AI-style signal board\nডেমো সিগন্যাল • Move • Close"); sub.setTextColor(Color.rgb(170,180,208)); sub.setTextSize(16); sub.setGravity(Gravity.CENTER); root.addView(sub,new LinearLayout.LayoutParams(-1,dp(80)));
        Button permission=new Button(this); permission.setText("১. Overlay Permission দিন"); permission.setOnClickListener(v->{ if(!Settings.canDrawOverlays(this)){ startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); }}); root.addView(permission,new LinearLayout.LayoutParams(-1,dp(58)));
        Button start=new Button(this); start.setText("২. Floating Board চালু করুন"); start.setOnClickListener(v->{ if(Settings.canDrawOverlays(this)){ startForegroundService(new Intent(this,OverlayService.class)); } else { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); }}); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(58)); sp.topMargin=dp(14); root.addView(start,sp);
        Button stop=new Button(this); stop.setText("Board বন্ধ করুন"); stop.setOnClickListener(v->stopService(new Intent(this,OverlayService.class))); LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,dp(58)); tp.topMargin=dp(14); root.addView(stop,tp);
        TextView note=new TextView(this); note.setText("নোট: বর্তমান version-এর UP/DOWN সিগন্যাল demo logic। কোনো broker/market API-র সাথে যুক্ত নয়।"); note.setTextColor(Color.rgb(170,180,208)); note.setTextSize(13); note.setPadding(0,dp(25),0,0); root.addView(note,new LinearLayout.LayoutParams(-1,-2));
        setContentView(root);
    }
}
