package com.autoboard.signal;

import android.app.*; import android.content.*; import android.graphics.*; import android.graphics.drawable.GradientDrawable; import android.os.*; import android.view.*; import android.widget.*; import java.text.SimpleDateFormat; import java.util.*;

public class OverlayService extends Service {
    WindowManager wm; FrameLayout box; TextView signal,time,ai; int x=30,y=180; Handler h=new Handler(Looper.getMainLooper()); int tick=0;
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);} 
    @Override public void onCreate(){super.onCreate(); createNotification(); showBoard();}
    void createNotification(){ String ch="board"; NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(ch,"AutoBoard",NotificationManager.IMPORTANCE_LOW)); Notification n=new Notification.Builder(this,ch).setContentTitle("AutoBoard running").setContentText("Floating board is active").setSmallIcon(android.R.drawable.ic_dialog_info).build(); startForeground(77,n); }
    TextView tv(String t,int size){ TextView v=new TextView(this); v.setText(t); v.setTextColor(Color.WHITE); v.setTextSize(size); v.setGravity(Gravity.CENTER); return v; }
    void showBoard(){
        wm=(WindowManager)getSystemService(WINDOW_SERVICE); box=new FrameLayout(this); box.setPadding(dp(10),dp(8),dp(10),dp(10));
        GradientDrawable bg=new GradientDrawable(); bg.setColor(Color.argb(235,18,24,43)); bg.setCornerRadius(dp(28)); bg.setStroke(dp(1),Color.argb(130,108,99,255)); box.setBackground(bg);
        TextView close=tv("×",20); FrameLayout.LayoutParams cp=new FrameLayout.LayoutParams(dp(30),dp(30),Gravity.RIGHT|Gravity.TOP); box.addView(close,cp); close.setOnClickListener(v->stopSelf());
        ai=tv("●  AI PRO",11); ai.setTextColor(Color.rgb(180,190,255)); FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(-1,dp(28)); ap.topMargin=dp(4); box.addView(ai,ap);
        signal=tv("WAIT",25); signal.setTypeface(null,1); FrameLayout.LayoutParams sg=new FrameLayout.LayoutParams(-1,dp(60)); sg.topMargin=dp(30); box.addView(signal,sg);
        time=tv("00:00:00",12); time.setTextColor(Color.LTGRAY); FrameLayout.LayoutParams tp=new FrameLayout.LayoutParams(-1,dp(25)); tp.topMargin=dp(88); box.addView(time,tp);
        final WindowManager.LayoutParams lp=new WindowManager.LayoutParams(dp(170),dp(135),Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,PixelFormat.TRANSLUCENT); lp.gravity=Gravity.TOP|Gravity.START; lp.x=x; lp.y=y;
        box.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy; public boolean onTouch(View v,MotionEvent e){if(e.getAction()==0){sx=e.getRawX();sy=e.getRawY();ox=lp.x;oy=lp.y;return true;} if(e.getAction()==2){lp.x=ox+(int)(e.getRawX()-sx);lp.y=oy+(int)(e.getRawY()-sy);wm.updateViewLayout(box,lp);return true;} return true;}});
        wm.addView(box,lp); update();
    }
    void update(){ if(signal==null)return; String s; tick++; int r=tick%3; if(r==1)s="▲  UP"; else if(r==2)s="▼  DOWN"; else s="WAIT"; signal.setText(s); signal.setTextColor(r==1?Color.rgb(65,230,140):r==2?Color.rgb(255,90,105):Color.WHITE); time.setText(new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date())); h.postDelayed(this::update,3000); }
    @Override public void onDestroy(){h.removeCallbacksAndMessages(null); if(box!=null&&wm!=null)wm.removeView(box); super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
