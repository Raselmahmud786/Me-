package com.example.signalstyle;
import android.app.*;import android.os.*;import android.graphics.*;import android.graphics.drawable.*;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity{
 int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
 TextView signal,sub,clock; Random r=new Random(); Chart chart;
 GradientDrawable round(int c,float rad){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(rad));return g;}
 TextView t(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);v.setGravity(Gravity.CENTER);return v;}
 @Override public void onCreate(Bundle b){super.onCreate(b);build();}
 void build(){
  int W=Color.WHITE,M=Color.rgb(143,158,184),P=Color.rgb(16,28,47),BG=Color.rgb(6,13,24);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);

  LinearLayout bar=new LinearLayout(this);bar.setPadding(dp(8),dp(4),dp(8),dp(4));bar.setGravity(Gravity.CENTER_VERTICAL);
  TextView menu=t("☰",24,W);bar.addView(menu,new LinearLayout.LayoutParams(dp(45),dp(48)));
  TextView pair=t("NZD/CHF\nOTC  ▾",13,W);pair.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);bar.addView(pair,new LinearLayout.LayoutParams(0,dp(48),1));
  TextView bal=t("$4,444.00\n+ $124.00",11,Color.rgb(80,235,170));bar.addView(bal,new LinearLayout.LayoutParams(dp(100),dp(48)));
  root.addView(bar);

  FrameLayout box=new FrameLayout(this);box.setBackgroundColor(Color.rgb(18,34,56));
  chart=new Chart();box.addView(chart,new FrameLayout.LayoutParams(-1,-1));

  LinearLayout tradeInfo=new LinearLayout(this);tradeInfo.setOrientation(LinearLayout.VERTICAL);tradeInfo.setPadding(dp(8),dp(7),dp(8),dp(7));
  tradeInfo.setBackground(round(Color.argb(170,8,18,31),10));
  TextView ei=t("END OF TRADE",10,M);ei.setGravity(Gravity.RIGHT);tradeInfo.addView(ei);
  clock=t("00:42",18,W);clock.setGravity(Gravity.RIGHT);tradeInfo.addView(clock);
  FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(dp(115),dp(62),Gravity.RIGHT|Gravity.TOP);ip.topMargin=dp(10);ip.rightMargin=dp(8);box.addView(tradeInfo,ip);

  LinearLayout orb=new LinearLayout(this);orb.setOrientation(LinearLayout.VERTICAL);orb.setGravity(Gravity.CENTER);
  signal=t("WAIT",12,W);sub=t("AI SIGNAL",8,Color.rgb(170,185,210));orb.addView(signal,new LinearLayout.LayoutParams(-1,dp(25)));orb.addView(sub,new LinearLayout.LayoutParams(-1,dp(18)));
  GradientDrawable og=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(20,220,150),Color.rgb(40,110,255),Color.rgb(240,55,150)});og.setShape(GradientDrawable.OVAL);og.setStroke(dp(2),Color.WHITE);orb.setBackground(og);
  FrameLayout.LayoutParams op=new FrameLayout.LayoutParams(dp(82),dp(82),Gravity.CENTER);op.leftMargin=dp(55);op.topMargin=dp(150);box.addView(orb,op);
  root.addView(box,new LinearLayout.LayoutParams(-1,0,1));

  LinearLayout panel=new LinearLayout(this);panel.setOrientation(LinearLayout.VERTICAL);panel.setPadding(dp(9),dp(6),dp(9),dp(7));panel.setBackgroundColor(P);
  LinearLayout stats=new LinearLayout(this);
  String[] a={"TIME\n11:08","INVESTMENT\n$100","PAYOUT\n$185","PROFIT\n+$85"};
  for(String s:a){TextView v=t(s,11,M);stats.addView(v,new LinearLayout.LayoutParams(0,dp(52),1));} panel.addView(stats);

  LinearLayout bs=new LinearLayout(this);bs.setPadding(0,dp(3),0,dp(3));
  Button up=new Button(this);up.setText("▲  UP");up.setTextColor(W);up.setTextSize(15);up.setBackground(round(Color.rgb(0,200,125),12));
  Button down=new Button(this);down.setText("▼  DOWN");down.setTextColor(W);down.setTextSize(15);down.setBackground(round(Color.rgb(242,68,76),12));
  bs.addView(up,new LinearLayout.LayoutParams(0,dp(55),1));bs.addView(down,new LinearLayout.LayoutParams(0,dp(55),1));
  panel.addView(bs);
  Button ai=new Button(this);ai.setText("🤖  GENERATE AI SIGNAL");ai.setTextColor(W);ai.setTextSize(13);ai.setBackground(round(Color.rgb(53,87,220),12));
  ai.setOnClickListener(v->makeSignal());panel.addView(ai,new LinearLayout.LayoutParams(-1,dp(48)));
  root.addView(panel,new LinearLayout.LayoutParams(-1,dp(185)));
  setContentView(root);
  makeSignal();
 }
 void makeSignal(){int x=r.nextInt(3);String s=x==0?"CALL / UP":x==1?"PUT / DOWN":"WAIT";signal.setText(s);signal.setTextColor(x==0?Color.rgb(70,255,170):x==1?Color.rgb(255,105,110):Color.WHITE);sub.setText(x==2?"WAIT FOR CONFIRMATION":"AI TECHNICAL SIGNAL");}
 class Chart extends View{
  Paint p=new Paint(3);float[] v=new float[42];
  Chart(){super(MainActivity.this);for(int i=0;i<v.length;i++)v[i]=.45f+r.nextFloat()*.35f;}
  protected void onDraw(Canvas c){int w=getWidth(),h=getHeight();p.setStrokeWidth(1);p.setColor(Color.argb(30,255,255,255));
   for(int i=1;i<8;i++)c.drawLine(0,i*h/8f,w,i*h/8f,p);for(int i=1;i<7;i++)c.drawLine(i*w/7f,0,i*w/7f,h,p);
   float lo=.1f,hi=.95f;for(int i=0;i<v.length;i++){float x=dp(5)+i*(w-dp(10))/(v.length-1);float y=h-(v[i]-lo)/(hi-lo)*(h-dp(30))-dp(15);boolean up=i%4!=1;p.setColor(up?Color.rgb(0,220,140):Color.rgb(247,73,76));p.setStrokeWidth(dp(2));c.drawLine(x,y-dp(15),x,y+dp(15),p);c.drawRect(x-dp(5),y-dp(9),x+dp(5),y+dp(9),p);}
   p.setColor(Color.rgb(70,150,255));p.setStrokeWidth(dp(2));c.drawLine(0,h*.51f,w,h*.51f,p);
  }
 }
}